#define _GNU_SOURCE
#include "sbuffer.h"
#include "config.h"
#include "connmgr.h"
#include "datamgr.h"
#include "sensor_db.h"
#include <error.h>
#include <inttypes.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/stat.h>

#define FIFO_NAME "log_Info"
#define BUF_MAX 255

#define CONNMGR 0
#define DATAMGR 1
#define STORMGR 2
//macro for connmgr print
#define OPENNODE 1
#define CLOSENODE 2
//macro for datamgr print
#define TOOCOLD 1
#define TOOWARM 2
#define INVALIDID 3
//macro for dbmgr print
#define CONN_SET 1
#define NEW_TABLE 2
#define CONN_LOST 3
#define NO_CONN 4

/*
  Part of the code refers to the lecture code fork.c and fifo.c
  log_event() is a child-process to deal with fifo and log. ConnmgrWrite(), DatamgrRead() and StormgrRead() are respectively 3 thread functions.
*/

FILE *fp_log;
char *send_buf;
pthread_mutex_t mutex_fifo;
// the print function is used by datamgr.c sensor_db.c and connmgr.c to print out in the fifo
void print_fifo_log(int mgr,int conn,int id,double temp,char *s);
int select_callback(void *data, int argc, char **argv, char **azColName);

sbuffer_t *buffer; //common shared buffer
unsigned char stop_flag; //

void *ConnmgrWrite(void *id)
{
  int thread_id=*(int *)id;
  printf("Connection write thread it:%d\n",thread_id);
  connmgr_listen(1111,&buffer);
  connmgr_free();
  stop_flag=1;
  printf("Connection writer thread finish\n");
  pthread_exit(NULL);
}

void *DatamgrRead(void *id)
{
  int thread_id=*(int *)id;
  printf("Datamgr read thread it:%d\n",thread_id); 
  FILE *fp_map=fopen("room_sensor.map", "r");           
  datamgr_parse_sensor_data(fp_map,&buffer,thread_id); 
  printf("%d\n",datamgr_get_total_sensors());
  printf("%ld\n",datamgr_get_last_modified(1));  
  printf("%lf\n",datamgr_get_avg(1234));
  printf("%lf\n",datamgr_get_avg(1));
  datamgr_free();
  fclose(fp_map);
  printf("Datamgr read thread finish\n");
  pthread_exit(NULL);
}

void *StormgrRead(void *id)
{
  int thread_id=*(int *)id;
  printf("Stormgr read thread it:%d\n",thread_id);
  sensor_data_t data;
  DBCONN * db;
  db=init_connection(1);
  while(!stop_flag)
  {
    if(sbuffer_remove_timed(buffer,&data,TIMEOUT,thread_id)==SBUFFER_SUCCESS)
    //if(sbuffer_remove(buffer,&data)==SBUFFER_SUCCESS)
      insert_sensor(db,data.id,data.value,data.ts);
    sleep(1);
  }
  find_sensor_all(db,&select_callback);
  find_sensor_by_value(db,12,&select_callback);
  find_sensor_exceed_value(db,19,&select_callback);
  find_sensor_by_timestamp(db,1524385791,&select_callback);
  find_sensor_after_timestamp(db,1524385791,&select_callback);
  disconnect(db);
  printf("Stormgr read thread finish\n");
  pthread_exit(NULL);
}

void log_event(void)
{
  FILE *fp_log;
  FILE *gateway=fopen("gateway.log","w");
  char *str_result;
  char recv_buf[BUF_MAX];
  int sequence_number=0;
  struct timeval tt;//timestamp to record
  pid_t my_pid;
  my_pid=getpid();
  printf("The child pid is %d\n",my_pid);
  mkfifo(FIFO_NAME,0666);
  fp_log=fopen(FIFO_NAME,"r");
  printf("syncing with reader ok\n");
  do
  {
    str_result=fgets(recv_buf,BUF_MAX,fp_log);
    if(str_result!=NULL)
    {
      gettimeofday(&tt,NULL);
      printf("%d %ld %s\n",sequence_number,tt.tv_sec,recv_buf);
      fprintf(gateway,"%s\n",recv_buf);
      sequence_number++;
    }
  }while(str_result!=NULL);
  fclose(fp_log);
  fclose(gateway);
  exit(EXIT_SUCCESS);
}

int main(int argc,char**argv)
{
  pid_t my_pid, child_pid;
  my_pid=getpid();
  printf("Parent process pid %d\n",my_pid);
  child_pid=fork();
  SYSCALL_ERROR(child_pid);
  if(child_pid==0)
  {
    log_event();
  }
  else{
    printf("Parent process %d creat child process %d\n",my_pid,child_pid);
    mkfifo(FIFO_NAME,0666);
    fp_log=fopen(FIFO_NAME,"w");
    printf("syncing with writer ok\n");
    sbuffer_init(&buffer);
    stop_flag=0;
    int id1,id2,id3,presult;
    pthread_t thread_conn,thread_stor,thread_data;
    pthread_mutex_init(&mutex_fifo,NULL);
    id1=1;
    presult=pthread_create(&thread_conn,NULL,&ConnmgrWrite,(void *)&id1);
    ERROR_HANDLER(presult,"Connmgr writer thread create failed\n");
    id2=2;
    presult=pthread_create(&thread_stor,NULL,&StormgrRead,(void*)&id2);
    ERROR_HANDLER(presult,"Stormgr reader thread create failed\n");
    id3=3;
    presult=pthread_create(&thread_data,NULL,&DatamgrRead,(void*)&id3);
    ERROR_HANDLER(presult,"Datamgr reader thread create failed\n");
    presult=pthread_join(thread_conn,NULL);
    ERROR_HANDLER(presult,"Connmgr writer thread join failed\n");
    presult=pthread_join(thread_stor,NULL);
    ERROR_HANDLER(presult,"Stormgr reader thread create failed\n");
    presult=pthread_join(thread_data,NULL);
    ERROR_HANDLER(presult,"Datamgr reader thread create failed\n");
    sbuffer_free(&buffer);
    fclose(fp_log);
    pthread_mutex_destroy(&mutex_fifo);
    exit(EXIT_SUCCESS);
  }
  return 0;
}

int select_callback(void *data, int argc, char **argv, char **azColName)
{
  printf("%s",(char*)data);
  for(int i=0;i<argc;i++)
  {
     printf("%s = %s\n",azColName[i],argv[i]?argv[i]:"NULL");
  }
  printf("\n");
  return 0;
}

void print_fifo_log(int mgr,int conn,int id,double temp,char *s)
{
    if(mgr==CONNMGR)//print from connection manager
    {
      if(conn==OPENNODE)
        asprintf(&send_buf,"A sensor node with %d has opened a new connection\n",id);
      else if(conn==CLOSENODE)
        asprintf(&send_buf,"The sensor node with %d has closed the connection\n",id);
    }
    else if(mgr==DATAMGR)//print from data manager
    {
      if(conn==TOOCOLD)
        asprintf(&send_buf,"The sensor node with ID %hu reports it’s too cold (running avg temperature = %lf)\n",id,temp);
      else if (conn==TOOWARM)
        asprintf(&send_buf,"The sensor node with ID %hu reports it’s too hot (running avg temperature = %lf)\n",id,temp);
      else if (conn==INVALIDID)
        asprintf(&send_buf,"Received sensor data with invalid sensor node ID %d\n",id);
    }
    else if (mgr==STORMGR)//print from storage manager
    {
      if(conn==CONN_SET)
        asprintf(&send_buf,"Connection to SQL server established.\n");
      else if (conn==NEW_TABLE)
        asprintf(&send_buf,"New table %s created.\n",s);
      else if (conn==CONN_LOST)
        asprintf(&send_buf,"Connection to SQL server lost.\n");
      else if (conn==NO_CONN)
        asprintf(&send_buf,"Unable to connect to SQL server.\n");
    }
    pthread_mutex_lock(&mutex_fifo);
    if(fputs(send_buf,fp_log)==EOF)
    {
       fprintf(stderr,"Error wrting data to fifo\n");
       exit(EXIT_FAILURE);
    }
    pthread_mutex_unlock(&mutex_fifo);
    free(send_buf);
}

