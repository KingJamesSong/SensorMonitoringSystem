#define _GNU_SOURCE
#include <pthread.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include "sbuffer.h"

#define gettidv() syscall(__NR_gettid)

typedef struct sbuffer_node {
  struct sbuffer_node * next;
  sensor_data_t data;
  //volatile char read_flag;
  volatile int thread_id;//indicates which thread read the node
} sbuffer_node_t;

struct sbuffer {
  sbuffer_node_t * head;
  sbuffer_node_t * tail;
};	

static pthread_mutex_t mutex;
static pthread_mutexattr_t mutexattr;
static pthread_cond_t cond;
/*
  ptrhead_cond_wait() is one of the cancellation points of thread, which means if this thread is waiting, another thread can cancel the thread by its thread ID.
  So robust mutex is applied. When thread holding the mutex exits and other thread call pthread_mutex_lock(), a error of EOWNERDEAD will return. Then we can make the mutex consistent and unlock the mutex. Another solution is to add unlock
code in pthread_cleanup_push() function.
  Part of the robust mutex code refers to the blog below:
  https://blog.csdn.net/kxcfzyk/article/details/29240953

  Another member thread_id is added in the struct of sbuffer_node. The insert and remove procedure works in such process. Every time a data node is inserted, the attribute of this node is set to 0. If this data is read by reader thread, the situation depends on the value of the thread_id. If it is 0.it is set by the current thread ID. If it is the same with current thread ID, the node moves to next node. If the thread_id is not 0 but not equal with current thread ID, it shows another thread already reads it, then delete the node.
*/
int sbuffer_init(sbuffer_t ** buffer)
{
  *buffer = malloc(sizeof(sbuffer_t));
  if (*buffer == NULL) return SBUFFER_FAILURE;
  (*buffer)->head = NULL;
  (*buffer)->tail = NULL;
  pthread_mutexattr_init(&mutexattr);
  pthread_mutexattr_setrobust(&mutexattr,PTHREAD_MUTEX_ROBUST);
  pthread_mutex_init(&mutex,&mutexattr);
  pthread_cond_init(&cond,NULL);
  return SBUFFER_SUCCESS; 
}


int sbuffer_free(sbuffer_t ** buffer)
{
  if ((buffer==NULL) || (*buffer==NULL)) 
  {
    return SBUFFER_FAILURE;
  } 
  while ( (*buffer)->head )
  {
    sbuffer_node_t * dummy = (*buffer)->head;
    (*buffer)->head = (*buffer)->head->next;
    free(dummy);
  }
  free(*buffer);
  *buffer = NULL;
  pthread_mutex_destroy(&mutex);
  pthread_cond_destroy(&cond);
  return SBUFFER_SUCCESS;		
}


int sbuffer_remove(sbuffer_t * buffer,sensor_data_t * data,int id)
{
  //long int thread_id=(long int)gettidv();
  //SYSCALL_ERROR(thread_id);
  int thread_id=id;
  sbuffer_node_t * dummy;
  if (buffer == NULL) return SBUFFER_FAILURE;
  if (buffer->head == NULL) return SBUFFER_NO_DATA;
  *data = buffer->head->data;
  dummy = buffer->head;
  if(0==dummy->thread_id)
  {
    pthread_mutex_lock(&mutex);
    if(0==dummy->thread_id)//double check
      dummy->thread_id=thread_id;
  }
  else if(thread_id!=dummy->thread_id)//has been read by another thread,delete
  {
    pthread_mutex_lock(&mutex);
    if (buffer->head == buffer->tail) // buffer has only one node
    {
      buffer->head = buffer->tail = NULL; 
    }
    else  // buffer has many nodes 
    {
      buffer->head = buffer->head->next;
    }
    free(dummy);
  }
  else if(thread_id==dummy->thread_id)// has read by the thread itself
  {
    sbuffer_node_t * dummy_prev;
    while(dummy->thread_id==thread_id)
    {
      dummy_prev=dummy;
      dummy=dummy->next;
      if(dummy==NULL)//only one node in buffer
      {
        return SBUFFER_NO_DATA;
      }
      if(0==dummy->thread_id)//not accessed yet
      {
        pthread_mutex_lock(&mutex);
        dummy->thread_id=thread_id;
        *data = dummy->data;
        break;
      }
      else if(thread_id!=dummy->thread_id)
      {
        pthread_mutex_lock(&mutex);
        if(NULL==dummy->next)//dummy is at the tail!
        {
          buffer->tail=dummy_prev;
          *data = dummy->data;
          free(dummy);
          dummy=NULL;
        }
        else{
          dummy_prev->next=dummy->next;// remove the dummy node
          *data = dummy->data;
          free(dummy);
          dummy=NULL;
        }
        break;
      }
    }
  }
  pthread_mutex_unlock(&mutex);
  return SBUFFER_SUCCESS;
}

int sbuffer_remove_timed(sbuffer_t * buffer,sensor_data_t * data, int timeout,int id)
{
  sbuffer_node_t * dummy;
  //long int thread_id=(long int)gettidv();
  //SYSCALL_ERROR(thread_id);
  int thread_id=id;
  if (buffer == NULL) return SBUFFER_FAILURE;
  if (buffer->head == NULL) //during timeout block
  {
     struct timespec ts;//ns
     struct timeval tt;//us
     gettimeofday(&tt,NULL);//timedwait use the timespec of the system time
     ts.tv_sec=tt.tv_sec;
     ts.tv_nsec=tt.tv_usec*1000+timeout*1000*1000;
     ts.tv_sec+=ts.tv_nsec/(1000*1000*1000);
     ts.tv_nsec%=(1000*1000*1000);
     int result=1;
     while(EOWNERDEAD==pthread_mutex_lock(&mutex))
     {
        pthread_mutex_consistent(&mutex);
        pthread_mutex_unlock(&mutex);
     }
     result=pthread_cond_timedwait(&cond,&mutex,&ts);
     pthread_mutex_unlock(&mutex);
     if(result==0)
     {
         if(buffer->head!=NULL)
         {
           *data = buffer->head->data;
           dummy = buffer->head;
           if(thread_id==dummy->thread_id)
           {
             return SBUFFER_NO_DATA;
           }
           else
           {
              pthread_mutex_lock(&mutex);
              if(dummy->thread_id==0)
                dummy->thread_id=thread_id;
              else if(thread_id!=dummy->thread_id)
              {
                free(dummy);
                dummy=NULL;
                buffer->head = buffer->tail = NULL;
              }
              pthread_mutex_unlock(&mutex);
           }
           return SBUFFER_SUCCESS;
         }
         else
         {
           return SBUFFER_NO_DATA;
         }
     }
     else
     {
         return SBUFFER_NO_DATA;
     }
  }
  else //buffer has many nodes
  {
    *data = buffer->head->data;
    dummy = buffer->head;
    if(0==dummy->thread_id)
    {
     pthread_mutex_lock(&mutex);
     if(0==dummy->thread_id)//double check
       dummy->thread_id=thread_id;
    }
    else if(thread_id!=dummy->thread_id)//has been read by another thread,delete
    {
      pthread_mutex_lock(&mutex);
      if (buffer->head == buffer->tail) // buffer has only one node
      {
        buffer->head = buffer->tail = NULL; 
      }
      else  // buffer has many nodes empty
      {
        buffer->head = buffer->head->next;
      }
      free(dummy);
    }
    else if(thread_id==dummy->thread_id)// has read by the thread itself
    {
      sbuffer_node_t * dummy_prev;
      while(dummy->thread_id==thread_id)
      {
       dummy_prev=dummy;
       dummy=dummy->next;
       if(dummy==NULL)//only one node
       {
         
         //pthread_mutex_unlock(&mutex);
         return SBUFFER_NO_DATA;
       }
       if(0==dummy->thread_id)//not accessed yet
       {
         pthread_mutex_lock(&mutex);
         dummy->thread_id=thread_id;
         *data = dummy->data;
         break;
       }
       else if(thread_id!=dummy->thread_id)
       {
         pthread_mutex_lock(&mutex);
         if(NULL==dummy->next)//dummy is at the tail!
         {
           buffer->tail=dummy_prev;
           *data = dummy->data;
           free(dummy);
           dummy=NULL;
         }
         else
         {
           dummy_prev->next=dummy->next;// remove the dummy node
           *data = dummy->data;
           free(dummy);
           dummy=NULL;
         }
         break;
       }
     }
   }
   pthread_mutex_unlock(&mutex);
  }
  return SBUFFER_SUCCESS;
}

int sbuffer_insert(sbuffer_t * buffer, sensor_data_t * data)
{
  sbuffer_node_t * dummy;
  if (buffer == NULL) return SBUFFER_FAILURE;
  dummy = malloc(sizeof(sbuffer_node_t));
  if (dummy == NULL) return SBUFFER_FAILURE;
  dummy->data = *data;
  dummy->next = NULL;
  dummy->thread_id=0;
  if (buffer->tail == NULL) // buffer empty (buffer->head should also be NULL
  {  
    while(EOWNERDEAD==pthread_mutex_lock(&mutex))
    {
      pthread_mutex_consistent(&mutex);
      pthread_mutex_unlock(&mutex);
    }
    buffer->head = buffer->tail = dummy;
    pthread_cond_broadcast(&cond);
    pthread_mutex_unlock(&mutex);
  } 
  else // buffer not empty
  {
    pthread_mutex_lock(&mutex);
    buffer->tail->next = dummy;
    buffer->tail = buffer->tail->next; 
    pthread_mutex_unlock(&mutex);
  }
  return SBUFFER_SUCCESS;
}



