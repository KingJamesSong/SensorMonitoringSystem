#include <stdlib.h>
#include <stdio.h>
#include <assert.h>
#include "dplist.h"

/*
 * definition of error codes
 * */
#define DPLIST_NO_ERROR 0
#define DPLIST_MEMORY_ERROR 1 // error due to mem alloc failure
#define DPLIST_INVALID_ERROR 2 //error due to a list operation applied on a NULL list 

#ifdef DEBUG
	#define DEBUG_PRINTF(...) 									         \
		do {											         \
			fprintf(stderr,"\nIn %s - function %s at line %d: ", __FILE__, __func__, __LINE__);	 \
			fprintf(stderr,__VA_ARGS__);								 \
			fflush(stderr);                                                                          \
                } while(0)
#else
	#define DEBUG_PRINTF(...) (void)0
#endif


#define DPLIST_ERR_HANDLER(condition,err_code)\
	do {						            \
            if ((condition)) DEBUG_PRINTF(#condition " failed\n");    \
            assert(!(condition));                                    \
        } while(0)

        
/*
 * The real definition of struct list / struct node
 */

struct dplist_node {
  dplist_node_t * prev, * next;
  void * element;
};

struct dplist {
  dplist_node_t * head;
  void * (*element_copy)(void * src_element);			  
  void (*element_free)(void ** element);
  int (*element_compare)(void * x, void * y);
};


dplist_t * dpl_create (// callback functions
			  void * (*element_copy)(void * src_element),
			  void (*element_free)(void ** element),
			  int (*element_compare)(void * x, void * y)
			  )
{
  dplist_t * list;
  list = malloc(sizeof(struct dplist));
  DPLIST_ERR_HANDLER(list==NULL,DPLIST_MEMORY_ERROR);
  list->head = NULL;  
  list->element_copy = element_copy;
  list->element_free = element_free;
  list->element_compare = element_compare; 
  return list;
}

void dpl_free(dplist_t ** list, bool free_element)
{
  assert(list!=NULL);
  //assert((*list)!=NULL);
  dplist_node_t * list_node;
  DPLIST_ERR_HANDLER(list==NULL,DPLIST_INVALID_ERROR);
  while((*list)->head!=NULL)
  {
    list_node=(*list)->head;
    (*list)->head=(*list)->head->next;
    if(free_element==false)
    {
      free(list_node->element);
      list_node->element=NULL;
    }
    else if(free_element==true)
    {
      (*list)->element_free((void **)&list_node->element);
    }
    free(list_node);
    list_node=NULL;
  }
  free(*list);
  *list=NULL;
    // add your code here
}

dplist_t * dpl_insert_at_index(dplist_t * list, void * element, int index, bool insert_copy)
{
  dplist_node_t * ref_at_index, * list_node;
  DPLIST_ERR_HANDLER(list==NULL,DPLIST_INVALID_ERROR);
  list_node = malloc(sizeof(dplist_node_t));
  DPLIST_ERR_HANDLER(list_node==NULL,DPLIST_MEMORY_ERROR);
  if(insert_copy==false)
  {
    list_node->element =element;
  }
  else if(insert_copy==true)
  {
    list_node->element=list->element_copy(element);
  }
  // pointer drawing breakpoint
  if (list->head == NULL)  
  { // covers case 1 
    list_node->prev = NULL;
    list_node->next = NULL;
    list->head = list_node;
    // pointer drawing breakpoint
  } else if (index <= 0)  
  { // covers case 2 
    list_node->prev = NULL;
    list_node->next = list->head;
    list->head->prev = list_node;
    list->head = list_node;
    // pointer drawing breakpoint
  } else 
  {
    ref_at_index = dpl_get_reference_at_index(list, index);  
    assert( ref_at_index != NULL);
    // pointer drawing breakpoint
    if (index < dpl_size(list))
    { // covers case 4
      list_node->prev = ref_at_index->prev;
      list_node->next = ref_at_index;
      ref_at_index->prev->next = list_node;
      ref_at_index->prev = list_node;
      // pointer drawing breakpoint
    } else
    { // covers case 3 
      assert(ref_at_index->next == NULL);
      list_node->next = NULL;
      list_node->prev = ref_at_index;
      ref_at_index->next = list_node;    
      // pointer drawing breakpoint
    }
  }
  return list;
    // add your code here
}

dplist_t * dpl_remove_at_index( dplist_t * list, int index, bool free_element)
{
  dplist_node_t * ref_at_index;
  DPLIST_ERR_HANDLER(list==NULL,DPLIST_INVALID_ERROR);
  int flag=1;
  if(dpl_size(list)==1)
  {
    ref_at_index=list->head;
    flag=0;
  }
  else if(dpl_size(list)==0)
    return list;
  else if(index<=0)
  {
    ref_at_index=list->head;
    list->head=ref_at_index->next;
    ref_at_index->next->prev=NULL;
  }
  else if(index>=dpl_size(list)-1)
  {
    ref_at_index = dpl_get_reference_at_index(list, dpl_size(list)-1);
    ref_at_index->prev->next=NULL;
  }
  else
  {
    ref_at_index = dpl_get_reference_at_index(list, index);  
    assert( ref_at_index != NULL);
    ref_at_index->prev->next=ref_at_index->next;
    ref_at_index->next->prev=ref_at_index->prev;
  }

  if(free_element==false)
  {
    free(ref_at_index->element);
    ref_at_index->element=NULL;
    free(ref_at_index);
    ref_at_index=NULL;
    assert(ref_at_index==NULL);
    if(flag==0)
      list->head=NULL;
  }
  else if(free_element==true)
  {
    list->element_free((void **)(&ref_at_index->element));
    free(ref_at_index);
    ref_at_index=NULL; 
    assert(ref_at_index==NULL);
    if(flag==0)
      list->head=NULL;
  }
  return list;
    // add your code here
}

int dpl_size( dplist_t * list )
{
  DPLIST_ERR_HANDLER(list==NULL,DPLIST_INVALID_ERROR);
  int size=0;
  dplist_node_t * dummy;
  dummy=list->head;
  while(dummy!=NULL)
  {
     dummy=dummy->next;
     size++;
  }
  dummy=NULL;
  return size;
   // add your code here
}

dplist_node_t * dpl_get_reference_at_index( dplist_t * list, int index )
{

  dplist_node_t * dummy;
  DPLIST_ERR_HANDLER(list==NULL,DPLIST_INVALID_ERROR);
  if (list->head == NULL) return NULL;
  else if(index<=0)
  {
    return list->head;
  }

  else{
    int count;
    for(dummy = list->head,count = 0;dummy->next!= NULL;dummy = dummy->next,count++) 
    { 
      if (count >= index) return dummy;
    }  
  } 
  return dummy; 
    // add your code here
}

void * dpl_get_element_at_index( dplist_t * list, int index )
{
  DPLIST_ERR_HANDLER(list==NULL,DPLIST_INVALID_ERROR);
  if (list->head == NULL ) return (void *)0;
  else{
    return dpl_get_reference_at_index(list,index)->element;
  }
    // add your code here
}

int dpl_get_index_of_element( dplist_t * list, void * element )
{
  int count=0;
  dplist_node_t * dummy;
  DPLIST_ERR_HANDLER(list==NULL,DPLIST_INVALID_ERROR);
  if (list->head == NULL ) return -1;
  for ( dummy = list->head; dummy!= NULL ; dummy = dummy->next,count++) 
  {
     if(list->element_compare(dummy->element,element)==0)
        return count;
  }
  return -1;
    // add your code here
}

// HERE STARTS THE EXTRA SET OF OPERATORS //

// ---- list navigation operators ----//
  
dplist_node_t * dpl_get_first_reference( dplist_t * list )
{
  DPLIST_ERR_HANDLER(list==NULL,DPLIST_INVALID_ERROR);
  if(list->head==NULL)
     return NULL;
  else
  return list->head;
    // add your code here
}

dplist_node_t * dpl_get_last_reference( dplist_t * list )
{
  DPLIST_ERR_HANDLER(list==NULL,DPLIST_INVALID_ERROR);
  if(list->head==NULL)
     return NULL;
  else
     return dpl_get_reference_at_index(list,dpl_size(list)-1);
    // add your code here
}

dplist_node_t * dpl_get_next_reference( dplist_t * list, dplist_node_t * reference )
{
  DPLIST_ERR_HANDLER(list==NULL,DPLIST_INVALID_ERROR);
  if(list->head==NULL||reference==NULL) return NULL;
  else if(dpl_get_index_of_reference(list,reference)!=-1){
     return reference->next;
  }
  else{
     return NULL;
  }
    // add your code here
}

dplist_node_t * dpl_get_previous_reference( dplist_t * list, dplist_node_t * reference )
{
  DPLIST_ERR_HANDLER(list==NULL,DPLIST_INVALID_ERROR);
  if(list->head==NULL) return NULL;
  for(dplist_node_t * dummy=dpl_get_reference_at_index(list,0);dummy->next!=NULL;dummy=dummy->next)
 {
    if(dummy==reference)
    {
       return dummy->prev;
    }
 }
 if(dpl_get_reference_at_index(list,dpl_size(list)-1)==reference)
    return reference->prev;
 if(reference==NULL)
    return dpl_get_reference_at_index(list,dpl_size(list)-1);
 return NULL;
    // add your code here
}

// ---- search & find operators ----//  
  
void * dpl_get_element_at_reference( dplist_t * list, dplist_node_t * reference )
{
  if(list->head==NULL) return NULL;
  else if(reference==NULL||reference==dpl_get_reference_at_index(list,dpl_size(list)-1))
     return dpl_get_reference_at_index(list,dpl_size(list)-1)->element;
  else if(dpl_get_index_of_reference(list,reference)!=-1){
     return reference->element;
  }
  else{
     return NULL;
  }
    // add your code here
}

dplist_node_t * dpl_get_reference_of_element( dplist_t * list, void * element )
{
  if(list->head==NULL) return NULL;
  else if(dpl_get_index_of_element(list,element)!=-1){
     return dpl_get_reference_at_index(list,dpl_get_index_of_element(list,element));
  }
  else{
     return NULL;
}
    // add your code here
}

int dpl_get_index_of_reference( dplist_t * list, dplist_node_t * reference )
{
  int index=0;
  DPLIST_ERR_HANDLER(list==NULL,DPLIST_INVALID_ERROR);
  if(dpl_size(list)==0){return -1;}
  if(reference==NULL || reference==dpl_get_reference_at_index(list,dpl_size(list)-1))
  return dpl_size(list)-1;
  for(dplist_node_t * node=dpl_get_reference_at_index(list,0);
  node->next!=NULL;node=node->next)
  {
     if(node==reference)
         return index;
     index++;
  }
  return -1;
  // add your code here
}
  
// ---- extra insert & remove operators ----//

dplist_t * dpl_insert_at_reference( dplist_t * list, void * element, dplist_node_t * reference, bool insert_copy )
{
  if(reference==NULL)
    dpl_insert_at_index(list,element,dpl_size(list),insert_copy);
  else if(dpl_get_index_of_reference(list,reference)==-1)
    return list;
  else{
    int index=dpl_get_index_of_reference(list,reference);
    dpl_insert_at_index(list,element,index,insert_copy);
  }
  return list;
    // add your code here
}

dplist_t * dpl_insert_sorted( dplist_t * list, void * element, bool insert_copy )
{
   dplist_node_t * ref;
   ref=list->head;
   if(ref==NULL)
      dpl_insert_at_index(list,element,-1,insert_copy);
   else{
     int index=0;
     while(list->element_compare(element,ref->element)>0)
     {
       index++;
       if(ref->next!=NULL)
          ref=ref->next;
       else
          break;
     }
     dpl_insert_at_index(list,element,index,insert_copy);
   }
   return list;
    // add your code here
}

dplist_t * dpl_remove_at_reference( dplist_t * list, dplist_node_t * reference, bool free_element )
{
   DPLIST_ERR_HANDLER(list==NULL,DPLIST_INVALID_ERROR);
   if(list->head==NULL)
      return list;
   else if(reference==NULL)
   {
      dpl_remove_at_index(list,dpl_size(list),free_element);
      return list;
   }
   else if(dpl_get_index_of_reference(list,reference)==-1)
   {
      return list;
   }
   else{
      int index=dpl_get_index_of_reference(list,reference);
      dpl_remove_at_index(list,index ,free_element);
      return list;
   }
    // add your code here
}

dplist_t * dpl_remove_element( dplist_t * list, void * element, bool free_element )
{
  if(list->head==NULL || dpl_get_index_of_element(list,element)==-1)
      return list;
   else{
      int index=dpl_get_index_of_element(list,element);
      dpl_remove_at_index(list,index,free_element);
      return list;
   }
    // add your code here
}
  
// ---- you can add your extra operators here ----//



