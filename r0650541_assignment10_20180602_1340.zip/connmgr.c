#define _GNU_SOURCE
#include "connmgr.h"
#include "sbuffer.h"
#include "config.h"
#include "lib/tcpsock.h"
#include "lib/dplist.h"
#include <sys/epoll.h>
#include <sys/socket.h>
#include <string.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#define MAX_CONN 1024

#define CONNMGR 0

#define OPENNODE 1
#define CLOSENODE 2

/*
  For the connection manager, I use epoll in EdgeTriger mode and set all the 
handles in non-blocking mode.
  The code partly refers to the epoll manual and the website below:
  https://github.com/rudy-yuan/select-epoll/blob/master/epoll-server.c
*/
int setnonblocking(int sockfd);// set all the events in non-blocking mode
int list_compare_conn(void *x,void *y);
void* list_copy_conn(void *element);
void list_free_conn(void **element);

dplist_t *list_data=NULL;
int conn_stop;
FILE *fp_text;

extern void print_fifo_log(int mgr,int conn,int id,double temp,char *s);

int setnonblocking(int sockfd)
{
    if (fcntl(sockfd, F_SETFL, fcntl(sockfd, F_GETFD, 0)|O_NONBLOCK) == -1) 
    {
        return -1;
    }
    return 0;
}

int list_compare_conn(void *x,void *y)
{
  int *a=(int*)x;
  int *b=(int*)y;
  if(*a>*b)
    return 1;
  else if (*a<*b)
    return -1;
  else if(*a==*b)
    return 0;
  return 0;
}

void* list_copy_conn(void *element)
{
  sensor_data_t *elementcp=(sensor_data_t *)element;
  sensor_data_t *element2;
  element2=malloc(sizeof(sensor_data_t ));
  *element2=*elementcp;
  return element2;
}

void list_free_conn(void **element)
{
  free(*element);
   *element=NULL;
}

void connmgr_listen(int port_number, sbuffer_t ** buffer)
{
    int epfd, listenfd;
    int  connfd, sockfd, curfds;
    //declare events structure, ev for the server and events for clients
    struct epoll_event ev;
    struct epoll_event events[MAX_CONN];
    int sock_fd[MAX_CONN];//this array stores fd of clients
    int sock_id[MAX_CONN];//this array stores corresponding id of sensornode
    memset((void *)&sock_fd,-1,sizeof(sock_fd));//indicate no id stored 
    memset((void *)&sock_id,-1,sizeof(sock_id));
    memset((void *)&ev,0,sizeof(ev));
    tcpsock_t *server=NULL;
    tcpsock_t *client=NULL;
    tcp_passive_open(&server,port_number);
    // All the sockets should be set as nonblocking
    tcp_get_sd(server,&listenfd);
    setnonblocking(listenfd);   
    ev.events = EPOLLIN|EPOLLET;
    ev.data.fd = listenfd;
    epfd = epoll_create(MAX_CONN); //epoll file descriptor,the parameter does not matter since Epoll Version 2.16, larger than 0 is okay. 
    //register listenfd to the events
    epoll_ctl(epfd, EPOLL_CTL_ADD, listenfd, &ev);
    curfds = 1;
    int start_flag=0;
    conn_stop=0;
    fp_text = fopen("sensor_data_recv", "w");
    list_data = dpl_create(&list_copy_conn,&list_free_conn,&list_compare_conn);
    while(!conn_stop)
    {
        //wait for the events in timeout duration
        int nfds = epoll_wait(epfd, events, 1000, TIMEOUT*1000);
        if (nfds == -1)
	{
            perror("epoll_wait");
            break;
        }
        if(nfds>0)
          start_flag=0;
        if(start_flag==0&&nfds==0)
        {
          printf("No connection.server prepare to shut down\n");
          start_flag=1;
        }
        else if(start_flag==1&&nfds==0)
        {
          conn_stop=1;
          printf("No connection and shut down\n");
          break;
        }
        //Deal with all the events 
        for (int n = 0; n < nfds; ++n) 
	{
	    //New connection coming in
            if (events[n].data.fd == listenfd) 
	    {                        
                tcp_wait_for_connection(server,&client);
                tcp_get_sd(client,&connfd);
                if (connfd < 0) 
		{
                    perror("accept");
                    continue;
                } 
                else
                    printf("Connection socket is:%d\n", connfd);
                setnonblocking(connfd);
                //set mode to ET
                ev.events = EPOLLIN| EPOLLET;               
                ev.data.fd = connfd;
                //register
                epoll_ctl(epfd, EPOLL_CTL_ADD, connfd, &ev);
                curfds ++;
            } 
            else if (events[n].events & EPOLLIN)
	    {	
                
                printf("EPOLLIN\n");
                if ((sockfd = events[n].data.fd) < 0)
                    continue;
                sensor_data_t data;
                int bytes;
                int len1,len2,len3;         
                bytes = sizeof(data.id);
                len1 = recv(sockfd,(void *)&data.id,bytes,0);
                printf("data from sock %d\n",sockfd);
                for(int i=1;i<curfds;i++)
                {
                   if(sock_fd[i]<0)
                   {
                     print_fifo_log(CONNMGR,OPENNODE,data.id,(double)0,(char *)NULL);
                     sock_fd[i]=sockfd;
                     sock_id[i]=data.id;
                     break;
                   }
                }               
                bytes = sizeof(data.value);
                len2 = recv(sockfd,(void *)&data.value,bytes,0);
                bytes = sizeof(data.ts);
                //len3=tcp_receive(client,(void *)&data.ts,&bytes);
                len3 = recv(sockfd,(void *)&data.ts,bytes,0);
                if (len1>0&&len2>0&&len3>0)
                {
          printf("buffer insert sensor id = %" PRIu16 " - temperature = %g - timestamp = %ld\n", data.id, data.value, (long int)data.ts); 
                //insert to shared buffer
                sbuffer_insert(*buffer,&data); 
                int insert_flag=1;int write_flag=1; 
                if(dpl_size(list_data)<=0)
                {              
                   dpl_insert_at_index(list_data,(void *)&data,0,true);
                   insert_flag=0;
                }else{
                for(int i=0;i<=dpl_size(list_data);i++)
                {
                  sensor_data_t *dummy=dpl_get_element_at_index(list_data,i);
                  if(dummy->id==data.id)
                  {
                     insert_flag=0;
                     dummy->value=data.value;
                     if(data.ts>dummy->ts+TIMEOUT)//if this node timeout
                     {
                       dpl_remove_element(list_data,(void *)dummy,true);
                       write_flag=0;
                       epoll_ctl(epfd, EPOLL_CTL_DEL, sockfd, &ev);
                       close(sockfd);
                       print_fifo_log(CONNMGR,CLOSENODE,data.id,(double)0,(char *)NULL);
                       for(int i=0;i<curfds;i++)
                       {
                          if(data.id==sock_id[i])
                          {
                             sock_id[i]=-1;
                             sock_fd[i]=-1;
                             if(sock_id[i+1]>0&&sock_fd[i+1]>0)
                             //the array move 1 step
                             {
                               for(int j=i;j<curfds;j++)
                               {
                                sock_id[j]=sock_id[j+1];
                                sock_fd[j]=sock_fd[j+1];
                               }
                             }
                          }
                       }
                       curfds--;
                     }
                     else
                       dummy->ts=data.ts;
                  }
                }
                }
                   if(insert_flag)
                   {
                     dpl_insert_at_index(list_data,(void *)&data,0,true);
                   }
                   if(write_flag)
                   {
                     fwrite(&data.id, sizeof(data.id), 1, fp_text);
                     fwrite(&data.value, sizeof(data.value), 1, fp_text);
                     fwrite(&data.ts, sizeof(data.ts), 1, fp_text); 
                   }
                }
                else 
		{
                    if (len3 <= 0) 
		    {   
                        for(int i=0;i<curfds;i++)
                        {
                          if(events[n].data.fd==sock_fd[i])
                          {
                            print_fifo_log(CONNMGR,CLOSENODE,sock_id[i],(double)0,(char *)NULL);
                            sock_id[i]=-1;
                            sock_fd[i]=-1;
                            if(sock_id[i+1]>0&&sock_fd[i+1]>0)
                            //the array moves 1 step
                            {
                              for(int j=i;j<curfds;j++)
                              {
                                sock_id[j]=sock_id[j+1];
                                sock_fd[j]=sock_fd[j+1];
                              }
                            }
                          }
                        }
                        printf("%d,%s\n", errno, strerror(errno));
                        epoll_ctl(epfd, EPOLL_CTL_DEL, sockfd, &ev);
                        close(sockfd);
                        curfds--;
                        continue;
                    }
                } 
                ev.events=EPOLLIN|EPOLLET;       
            }
        }
        
    }   
    if(server!=NULL)
      tcp_close(&server);
    if(client!=NULL)
      tcp_close(&client);
    close(epfd);
    close(listenfd);
}

void connmgr_free()
{
 conn_stop=1;
 fclose(fp_text);
 printf("clean up memory\n");
 dpl_free(&list_data,true);
}





