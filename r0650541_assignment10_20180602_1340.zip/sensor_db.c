#define _GNU_SOURCE
#include "sensor_db.h"
#include <string.h>
#include <pthread.h>
#include <unistd.h>

#define STORMGR 2

#define CONN_SET 1
#define NEW_TABLE 2
#define CONN_LOST 3
#define NO_CONN 4
/*
  Some methods in the sensor manager refers to the blog below:
  https://www.cnblogs.com/lzjsky/p/3688324.html 
*/
extern void print_fifo_log(int mgr,int conn,int id,double temp,char *s);
//some common variables use in lots of functions for use to connect to database
char *zErrMsg;
char *sql;
int result;
const char *function_data;

DBCONN * init_connection(char clear_up_flag)
{
  DBCONN *db;
  zErrMsg=NULL;
  sql=NULL;
  function_data=NULL;
  //connect database server
  int conn_time=3;//if no success, connection for 3 times
  do{
    result=sqlite3_open(TO_STRING(DB_NAME),&db);
    conn_time--;
    sleep(1);//wait a little bit
  }while(result!=SQLITE_OK && conn_time>=0);
  if(result)
  {
    //fprintf(stderr,"Unable to connect to SQL server: %s\n",sqlite3_errmsg(db));
    print_fifo_log(STORMGR,NO_CONN,0,(double)0,(void *)NULL);
    return NULL;
  }else{     
    print_fifo_log(STORMGR,CONN_SET,0,(double)0,(void *)NULL);
    //create table
    //fprintf(stderr,"Connection to SQL server established.\n");
    sql=sqlite3_mprintf("create table %s (\
               id integer primary key autoincrement not null,\
               sensor_id integer not null,\
               sensor_value decimal(4,2) not null,\
               timestamp time_t not null)",TO_STRING(TABLE_NAME)); 
    result=sqlite3_exec(db,sql,NULL,NULL,&zErrMsg);
    if(result==SQLITE_OK)
    {
      print_fifo_log(STORMGR,NEW_TABLE,0,(double)0,TO_STRING(TABLE_NAME));
      fprintf(stderr,"TABLE %s CREATE SUCCESSFULLY\n",TO_STRING(TABLE_NAME));
    }
    else if(result!= SQLITE_OK && clear_up_flag)
    {
      fprintf(stderr,"SQL ERROR: %s\n",zErrMsg);
      sqlite3_free(zErrMsg);
      char *sql_drop =sqlite3_mprintf("drop table %s",TO_STRING(TABLE_NAME));
      result=sqlite3_exec(db,sql_drop,NULL,NULL,&zErrMsg);
      sqlite3_free(zErrMsg);
      if(result==SQLITE_OK)
      fprintf(stderr,"DELETE TABLE %s DATA SUCCESSFULLY\n",TO_STRING(TABLE_NAME));
      sqlite3_exec(db,sql,NULL,NULL,&zErrMsg);
      sqlite3_free(sql_drop);
      sqlite3_free(zErrMsg);
    }
    else
    {
      sqlite3_free(zErrMsg);
    }
  }
  sqlite3_free(sql);
  return db;
}

void disconnect(DBCONN *conn)
{
   print_fifo_log(STORMGR,CONN_LOST,0,(double)0,(char *)NULL);
   sqlite3_close(conn);
}

int insert_sensor(DBCONN * conn, sensor_id_t id, sensor_value_t value, sensor_ts_t ts)
{ 
  zErrMsg=NULL;
  sql=sqlite3_mprintf("insert into %s (sensor_id,sensor_value,timestamp) values(%d,%4.2f,%ld)",TO_STRING(TABLE_NAME),id,value,ts);
  printf("%s\n",sql);
  result=sqlite3_exec(conn,sql,NULL,NULL,&zErrMsg);
  if(result!=SQLITE_OK)
  {
    fprintf(stderr,"INSERT FAIL:%s\n",zErrMsg);
    print_fifo_log(STORMGR,CONN_LOST,0,(double)0,(char *)NULL);
    sqlite3_free(zErrMsg);
  }
  sqlite3_free(sql);
  return result;
}

int insert_sensor_from_file(DBCONN * conn, FILE * sensor_data)
{
  
  //calculate the number of measurements;
  fseek(sensor_data,0,SEEK_END);
  int mea_num=ftell(sensor_data)/(sizeof(uint16_t)+sizeof(time_t)+sizeof(double));
  fseek(sensor_data,0,SEEK_SET);
  int id;double temp;time_t tt;
  for(int i=0;i<mea_num;i++)
  {
    fread(&id,sizeof(uint16_t),1,sensor_data);
    fread(&temp,sizeof(double),1,sensor_data);
    fread(&tt,sizeof(time_t),1,sensor_data);
    if(insert_sensor(conn,id,temp,tt)!=0)
       return 1;
  }
  return 0;
}

int find_sensor_all(DBCONN * conn, callback_t f)
{
  function_data="Find all sensors!\n";
  sql="select * from SensorData;";
  zErrMsg=NULL;
  result=sqlite3_exec(conn,sql,f,(void *)function_data,&zErrMsg);
  if(result!=SQLITE_OK)
  {
    fprintf(stderr,"Connection to SQL server lost.%s\n",zErrMsg);
    print_fifo_log(STORMGR,CONN_LOST,0,(double)0,(char *)NULL);
    //sqlite3_free(zErrMsg);
  }
  sqlite3_free(zErrMsg);
  return result;
}

int find_sensor_by_value(DBCONN * conn, sensor_value_t value, callback_t f)
{
  function_data="Find sensor_value equal!\n";
  sql=sqlite3_mprintf("select *from %s where sensor_value =%4.2f",TO_STRING(TABLE_NAME),value);
  zErrMsg=NULL;
  result=sqlite3_exec(conn,sql,f,(void *)function_data,&zErrMsg);
  if(result!=SQLITE_OK)
  {
    fprintf(stderr,"Connection to SQL server lost.%s\n",zErrMsg);
    print_fifo_log(STORMGR,CONN_LOST,0,(double)0,(char *)NULL);
    //sqlite3_free(zErrMsg);
  }
  sqlite3_free(zErrMsg);
  sqlite3_free(sql);
  return result;
}

int find_sensor_exceed_value(DBCONN * conn, sensor_value_t value, callback_t f)
{
  function_data="Find sensor_value exceed!\n";
  sql=sqlite3_mprintf("select *from %s where sensor_value>%4.2f",TO_STRING(TABLE_NAME),value);
  zErrMsg=NULL;
  result=sqlite3_exec(conn,sql,f,(void *)function_data,&zErrMsg);
  if(result!=SQLITE_OK)
  {
    fprintf(stderr,"Connection to SQL server lost.%s\n",zErrMsg);
    print_fifo_log(STORMGR,CONN_LOST,0,(double)0,(char *)NULL);
   // sqlite3_free(zErrMsg);
  }
  sqlite3_free(zErrMsg);
  sqlite3_free(sql);
  return result;
}

int find_sensor_by_timestamp(DBCONN * conn, sensor_ts_t ts, callback_t f)
{
  function_data="Find timestamp equal!\n";
  sql=sqlite3_mprintf("select *from %s where timestamp =%ld",TO_STRING(TABLE_NAME),ts);
  zErrMsg=NULL;
  result=sqlite3_exec(conn,sql,f,(void *)function_data,&zErrMsg);
  if(result!=SQLITE_OK)
  {
    fprintf(stderr,"Connection to SQL server lost.%s\n",zErrMsg);
    print_fifo_log(STORMGR,CONN_LOST,0,(double)0,(char *)NULL);
    //sqlite3_free(zErrMsg);
  }
  sqlite3_free(zErrMsg);
  sqlite3_free(sql);
  return result;
}

int find_sensor_after_timestamp(DBCONN * conn, sensor_ts_t ts, callback_t f)
{
  function_data="Find timestamp exceed\n";
  sql=sqlite3_mprintf("select *from %s where timestamp >%ld",TO_STRING(TABLE_NAME),ts);
  zErrMsg=NULL;
  result=sqlite3_exec(conn,sql,f,(void *)function_data,&zErrMsg);
  if(result!=SQLITE_OK)
  {
    fprintf(stderr,"Connection to SQL server lost.%s\n",zErrMsg);
    print_fifo_log(STORMGR,CONN_LOST,0,(double)0,(char *)NULL);
    //sqlite3_free(zErrMsg);
  }
  sqlite3_free(zErrMsg);
  sqlite3_free(sql);
  return result;
}




















