#define _GNU_SOURCE
#include "datamgr.h"
#include "sbuffer.h"
#include"lib/dplist.h"
#include <stdlib.h>
#include <unistd.h>
#include <inttypes.h>

#define DATAMGR 1

#define TOOCOLD 1
#define TOOWARM 2
#define INVALIDID 3

#define MAX_LENGTH 100//set maximum length for every sensor node

/*
  In the datamgr another struct room_data_t is defined in the config.h, whose member consist of sensor_data_t, the room ID and a pointer of temperature.
*/
dplist_t * list;
int map_num=0;
int mea_num=0;
void* list_copy_data(void *element);
void list_free_data(void **element);
int list_compare_data(void *x,void *y);
extern void print_fifo_log(int mgr,int conn,int id,double temp,char *s);
extern unsigned char stop_flag;

void datamgr_parse_sensor_files(FILE * fp_sensor_map, FILE * fp_sensor_data)
{ 
  ERROR_HANDLER(ftell(fp_sensor_data)==-1,"Invalid pointer");
  ERROR_HANDLER(ftell(fp_sensor_map)==-1,"Invalid pointer");
  list=NULL;
  //create list
  list = dpl_create(&list_copy_data,&list_free_data,&list_compare_data);
  //set cursor to end
  int start_map=ftell(fp_sensor_map);
  int start_data=ftell(fp_sensor_data);
  fseek(fp_sensor_map,0,SEEK_END);
  fseek(fp_sensor_data,0,SEEK_END);
  //calculate the num
  map_num=(ftell(fp_sensor_map)-start_map)/(sizeof(uint16_t)*2+sizeof(char)*2);
  mea_num=(ftell(fp_sensor_data)-start_data)/(sizeof(uint16_t)+sizeof(time_t)+sizeof(double));
  //set sursor to start
  fseek(fp_sensor_map,start_map,SEEK_SET);
  fseek(fp_sensor_data,start_data,SEEK_SET);
  for(int i=0;i<map_num;i++)
  {
    room_data_t * rdt = (room_data_t *)malloc(sizeof(room_data_t));
    ERROR_HANDLER(!rdt,"memory allocation");
    rdt->length=0;
    rdt->temp=NULL;
    fscanf(fp_sensor_map,"%hu %hu\n",&rdt->room,&(rdt->data).id);
    dpl_insert_at_index(list,rdt,0,true); 
    free(rdt);
    rdt=NULL;
  }
  // initialize temp
  uint16_t id;double temp;time_t tt;
  for(int i=0;i<mea_num;i++)
  {
    int non_exist_flag=1;
    fread(&id,sizeof(uint16_t),1,fp_sensor_data);
    fread(&temp,sizeof(double),1,fp_sensor_data);
    fread(&tt,sizeof(time_t),1,fp_sensor_data);
    for(int i=0;i<dpl_size(list);i++)
    {
       if(((room_data_t *)dpl_get_element_at_index(list,i))->data.id==id)
       {
        non_exist_flag=0;
        ((room_data_t *)dpl_get_element_at_index(list,i))->data.ts=tt;
        ((room_data_t *)dpl_get_element_at_index(list,i))->length++;
        *((room_data_t *)dpl_get_element_at_index(list,i))->temp++=temp;
        if(datamgr_get_avg(id)<SET_MIN_TEMP&&RUN_AVG_LENGTH<=((room_data_t *)dpl_get_element_at_index(list,i))->length)
           { 
              print_fifo_log(DATAMGR,TOOCOLD,((room_data_t *)dpl_get_element_at_index(list,i))->room,datamgr_get_avg(id),(void *)NULL);
              ((room_data_t *)dpl_get_element_at_index(list,i))->data.value=0;
           }
        if(datamgr_get_avg(id)>SET_MAX_TEMP&&RUN_AVG_LENGTH<=((room_data_t *)dpl_get_element_at_index(list,i))->length)
           {           
              print_fifo_log(DATAMGR,TOOWARM,((room_data_t *)dpl_get_element_at_index(list,i))->room,datamgr_get_avg(id),(void *)NULL);
              ((room_data_t *)dpl_get_element_at_index(list,i))->data.value=0;
           }
         ((room_data_t *)dpl_get_element_at_index(list,i))->data.value
=datamgr_get_avg(id);
       }
    }
    if(non_exist_flag)
       fprintf(stderr,"Non exsiting IDs\n");
  }
}

void datamgr_free()
{
   ERROR_HANDLER(list==NULL,"List is NULL");
   dpl_free(&list,true);
}

uint16_t datamgr_get_room_id(sensor_id_t sensor_id)
{
   ERROR_HANDLER(list==NULL,"List is NULL");
   int non_exist_flag=1;
   for(int i=0;i<dpl_size(list);i++)
   {
      if(((room_data_t *)dpl_get_element_at_index(list,i))->data.id==sensor_id)
         {
          non_exist_flag=0;
         return ((room_data_t *)dpl_get_element_at_index(list,i))->room;
         }
   }
   if(non_exist_flag)
     print_fifo_log(DATAMGR,INVALIDID,sensor_id,(double)0,(char *)NULL);
   return (uint16_t)0;
}

sensor_value_t datamgr_get_avg(sensor_id_t sensor_id)
{
   ERROR_HANDLER(list==NULL,"List is NULL");
   int non_exist_flag=1; 
   double sum=0;
   for(int i=0;i<dpl_size(list);i++)
    {
       if(((room_data_t *)dpl_get_element_at_index(list,i))->data.id==sensor_id)
       {  
          non_exist_flag=0;
          if(RUN_AVG_LENGTH>((room_data_t *)dpl_get_element_at_index(list,i))->length)
          {
            sum=0;
          }
          else
          {
            for(int j=0;j<RUN_AVG_LENGTH;j++)
            {
              (((room_data_t *)dpl_get_element_at_index(list,i))
->temp)--;
            sum+=*((room_data_t *)dpl_get_element_at_index(list,i))
->temp;
            }
            for(int j=0;j<RUN_AVG_LENGTH;j++)
            {
                (((room_data_t *)dpl_get_element_at_index(list,i))
->temp)++;
            }
          }
       }
    }  
    if(non_exist_flag)
     print_fifo_log(DATAMGR,INVALIDID,sensor_id,(double)0,(char *)NULL);
    return sum/RUN_AVG_LENGTH;
}

void datamgr_parse_sensor_data(FILE * fp_sensor_map, sbuffer_t ** buffer,int thread_id)
{
  if(list!=NULL)
    dpl_free(&list,true);
  list=NULL;
  //create list
  list = dpl_create(&list_copy_data,&list_free_data,&list_compare_data);
  //set cursor to end
  int start_map=ftell(fp_sensor_map);
  fseek(fp_sensor_map,0,SEEK_END);
  //calculate the num
  map_num=(ftell(fp_sensor_map)-start_map)/(sizeof(uint16_t)*2+sizeof(char)*2);
  mea_num=map_num*MAX_LENGTH;//set  upper limit of every node.
  //set sursor to start
  fseek(fp_sensor_map,start_map,SEEK_SET);
  room_data_t * rdt;
  for(int i=0;i<map_num;i++)
  {
    rdt = (room_data_t *)malloc(sizeof(room_data_t));
    ERROR_HANDLER(!rdt,"memory allocation");
    rdt->length=0;
    rdt->temp=NULL;
    fscanf(fp_sensor_map,"%hu %hu\n",&rdt->room,&(rdt->data).id);
    dpl_insert_at_index(list,rdt,0,true); 
    //free(rdt->temp);
    free(rdt);
    rdt=NULL;
  }
  sensor_data_t data;
  //data.id=0;data.value=(double )0;data.ts=0;
  int non_exist_flag;
  while(!stop_flag)
  {
    if(sbuffer_remove_timed(*buffer,&data,TIMEOUT,thread_id)==SBUFFER_SUCCESS)
    //if(sbuffer_remove(*buffer,&data)==SBUFFER_SUCCESS)
    {
      printf("datamgr read   sensor id = %" PRIu16 " - temperature = %g - timestamp = %ld\n", data.id, data.value, (long int)data.ts); 
      non_exist_flag=1;
      for(int i=0;i<dpl_size(list);i++)
      {
         if(((room_data_t *)dpl_get_element_at_index(list,i))->data.id==data.id)
         {
           non_exist_flag=0;
           ((room_data_t *)dpl_get_element_at_index(list,i))->data.ts=data.ts;
           ((room_data_t *)dpl_get_element_at_index(list,i))->length++;
           *((room_data_t *)dpl_get_element_at_index(list,i))->temp=data.value;
           (((room_data_t *)(dpl_get_element_at_index(list,i)))->temp)++;
           if(datamgr_get_avg(data.id)<SET_MIN_TEMP&&RUN_AVG_LENGTH<=((room_data_t *)dpl_get_element_at_index(list,i))->length)
           {  
              //judge if it is too cold 
              print_fifo_log(DATAMGR,TOOCOLD,((room_data_t *)dpl_get_element_at_index(list,i))->room,datamgr_get_avg(data.id),(void *)NULL);
              ((room_data_t *)dpl_get_element_at_index(list,i))->data.value=0;
           }
           else if(datamgr_get_avg(data.id)>SET_MAX_TEMP&&RUN_AVG_LENGTH<=((room_data_t *)dpl_get_element_at_index(list,i))->length)
           {      
              //judge if it is too warm     
              print_fifo_log(DATAMGR,TOOWARM,((room_data_t *)dpl_get_element_at_index(list,i))->room,datamgr_get_avg(data.id),(void *)NULL);
              ((room_data_t *)dpl_get_element_at_index(list,i))->data.value=0;
           }
           else
           ((room_data_t *)dpl_get_element_at_index(list,i))->data.value
=datamgr_get_avg(data.id);
         }
       }
       if(non_exist_flag)
         fprintf(stderr,"Non exsiting IDs\n");
   }
   sleep(1);
  }
}

time_t datamgr_get_last_modified(sensor_id_t sensor_id)
{
 ERROR_HANDLER(list==NULL,"List is NULL");
 int non_exist_flag=1;
 for(int i=0;i<dpl_size(list);i++)
   {
      if(((room_data_t *)dpl_get_element_at_index(list,i))->data.id==sensor_id)
      {  
         non_exist_flag=0;
         return ((room_data_t *)dpl_get_element_at_index(list,i))->data.ts;
      }
   }
  if(non_exist_flag)
     print_fifo_log(DATAMGR,INVALIDID,sensor_id,(double)0,(char *)NULL);
  return (time_t)0;
}

void* list_copy_data(void *element)
{
  room_data_t  *elementcp=(room_data_t *)element;
  room_data_t  *element2=(room_data_t  *)malloc(sizeof(room_data_t));
  ERROR_HANDLER(!element2,"Memory allocation");
  *element2=*elementcp;
  element2->temp=(double *)malloc(mea_num/map_num*sizeof(double));
   ERROR_HANDLER(!element2->temp,"Memory allocation");
  return element2;
}
void list_free_data(void **element)
{
  if(((room_data_t *)(*element))->temp!=NULL)
  {
    for(int i=0;i<((room_data_t *)(*element))->length;i++)
       (((room_data_t *)(*element))->temp)--;
    free(((room_data_t *)(*element))->temp);
    ((room_data_t *)*element)->temp=NULL;
  }
  free(*element);
   *element=NULL;
}

int list_compare_data(void *x,void *y)
{
  return 0;
}

int datamgr_get_total_sensors()
{
  ERROR_HANDLER(list==NULL,"List is NULL");
  return dpl_size(list);
}


